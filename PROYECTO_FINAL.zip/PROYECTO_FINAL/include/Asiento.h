#ifndef ASIENTO_H
#define ASIENTO_H

#include <GL/glut.h>		// Libreria de utilidades de OpenGL

/**
 * @brief Dibuja un cubo que representará el asiento del taburete
*/
void dibujaAsiento();

#endif // ASIENTO_H