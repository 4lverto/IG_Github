// Respaldo.h
#ifndef RESPALDO_H
#define RESPALDO_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>		// Libreria de utilidades de OpenGL

/**
 * @brief Dibuja un cubo que representará el respaldo del taburete
*/
void dibujaRespaldo();

#endif // RESPALDO_H