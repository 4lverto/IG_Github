#ifndef ASIENTO_H
#define ASIENTO_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>		// Libreria de utilidades de OpenGL

void dibujaAsiento();

#endif // ASIENTO_H