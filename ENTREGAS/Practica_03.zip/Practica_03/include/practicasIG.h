#include  "modelo.h"
#include  "mouse.h"
#include  "entradaTeclado.h"
#include  "visual.h"
#include  "file_ply_stl.h"

// Práctica 3
#include  "Respaldo.h"
#include  "Asiento.h"
#include  "Cilindro.h"
#include  "Taburete.h"