#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>		// Libreria de utilidades de OpenGL
#include "include/practicasIG.h"
#include <vector>
#include <stdbool.h>

using namespace std;

// PRÁCTICA 2 - Mallas con PLYs
Malla beethoven("plys/beethoven.ply",true);
Malla big_dodge("plys/big_dodge.ply",false);

// PRÁCTICA 3 - Componentes de mi modelo jerárquico articulado

bool animacionActiva=false; // Se gestiona con A y a
float VEL_Cilindro=0.01f;   // Se gestiona con T y G
float VEL_Asiento=0.5f;     // Se gestiona con Y y H
float VEL_Respaldo=0.1f;    // Se gestiona con U y J


// PRÁCTICA 4 - Mallas a dibujar y Dado

Dado dado(4.0f); // Dado "hereda" de Malla
Malla coche1("plys/big_dodge.ply",false); // Reflectividad difusa
Malla coche2("plys/big_dodge.ply",false); // Reflectividad ambiente
Malla coche3("plys/big_dodge.ply",false); // Reflectividad especular

// PRÁCTICA 4 - Dos focos de luz distintos

GLfloat posLuz1[4] = {5.0,5.0,10.0,0.0}; // Será el foco de luz por defecto (la que hemos tenido hasta ahora)
GLfloat posLuz2[4] = {-5.0,10.0,-5.0,1.0};

bool luzActiva=true;

/**
 * @brief Inicializa el modelo y de las variables globales
*/
void
initModel (){

  // ////////// //
  // Práctica 2 //
  // ////////// //
  beethoven.asignarReflectividadAmbiente(0.5f,0.5f,0.5f,0.6f);
  beethoven.asignarReflectividadEspecular(1.0f,1.0f,1.0f,1.0f);
  beethoven.asignarExponenteEspecular(49.0f);

  big_dodge.asignarReflectividadAmbiente(0.5f,0.5f,0.5f,0.6f);
  big_dodge.asignarReflectividadEspecular(1.0f,1.0f,1.0f,1.0f);
  big_dodge.asignarExponenteEspecular(49.0f);

  // ////////// //
  // Práctica 4 //
  // ////////// //

  dado.cargarTextura("JPEG/dado.jpg");
  dado.asignarReflectividadAmbiente(0.5f,0.5f,0.5f,0.6f);
  dado.asignarReflectividadEspecular(1.0f,1.0f,1.0f,1.0f);
  dado.asignarExponenteEspecular(49.0f);
  dado.setSombreadoSuave(true);

  coche1.cargarTextura("JPEG/texturaMarmol.jpg");
  coche1.calculoCoordenadasTexturaCilindrica();
  coche1.configuracionMaterial1();
  coche1.setSombreadoSuave(true);

  coche2.cargarTextura("JPEG/texturaMarmol.jpg");
  coche2.calculoCoordenadasTexturaCilindrica();
  coche2.configuracionMaterial2();
  coche2.setSombreadoSuave(true);

  coche3.configuracionMaterial3();
  coche3.setSombreadoSuave(true);
}

                  // /////////////// //
                  // "SUBCLASE" EJES //
                  // /////////////// //

class Ejes:Objeto3D { 
  public: 
      float longitud = 30;
  // Dibuja el objeto
  void draw( ){
    glBegin (GL_LINES);
    {
      glColor3f (0, 1, 0);
      glVertex3f (0, 0, 0);
      glVertex3f (0, longitud, 0);

      glColor3f (1, 0, 0);
      glVertex3f (0, 0, 0);
      glVertex3f (longitud, 0, 0);

      glColor3f (0, 0, 1);
      glVertex3f (0, 0, 0);
      glVertex3f (0, 0, longitud);
    }
    glEnd ();
  }
}; 

                    // ////////////////// //
                    // PROGRAMA PRINCIPAL //
                    // ////////////////// //

Ejes ejesCoordenadas;
int modo=GL_FILL;
bool iluminacionActivada=true;

/**
 *  @brief Función para gestionar el Modo de visualización de las figuras
*/
void setModo(int M){
  if(M==1){
    glPolygonMode(GL_FRONT_AND_BACK,GL_POINT);
  }else if(M==2){
    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
  }else if(M==3){
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
  }
}

/**
 *  @brief Función para gestionar la iluminación de las figuras
*/
void setIluminacion(){
  iluminacionActivada = !iluminacionActivada;
  
  if(iluminacionActivada){
    glEnable(GL_LIGHTING);
  }else{
    glDisable(GL_LIGHTING);
  }
}

// //////////
// PRÁCTICA 4 - Alternar entre los focos de luz definidos. Tecla W
// //////////

void establecerLuzActiva(){

  luzActiva = !luzActiva;

  if(luzActiva){
    glLightfv(GL_LIGHT0,GL_POSITION,posLuz1);
  }else{
    glLightfv(GL_LIGHT0,GL_POSITION,posLuz2);
  }

  glutPostRedisplay();
}

                                // ////////// //
                                // PRÁCTICA 5 //
                                // ////////// //

int objetoSeleccionado=-1;

// Implemento colorSeleccion //
// ///////////////////////// //

void colorSeleccion(int id){
  unsigned char r = id & 0xFF;
  glColor3ub(r,0,0);
}



// Creo dibujoEscena() a partir de lo que contenía Dibuja() //
// //////////////////////////////////////////////////////// //

// Se pone en negro
void dibujaEscena(bool seleccion) {
    glPushMatrix();
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Configura la transformación de visualización
    transformacionVisualizacion();

    // Dibujar los ejes (sin iluminación)
    glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
    glDisable(GL_LIGHTING);
    ejesCoordenadas.draw();
    glPopAttrib();

    if (seleccion) {
        // Modo selección: asignar colores únicos a cada objeto
        glDisable(GL_LIGHTING); // Desactiva la iluminación
        glDisable(GL_TEXTURE_2D); // Desactiva texturas

        colorSeleccion(1); dado.draw(); // Dado (ID 1)
        glTranslatef(10.0, 0.0, -10.0);
        colorSeleccion(2); coche1.draw(); // Coche 1 (ID 2)
        glTranslatef(0.0, 0.0, 10.0);
        colorSeleccion(3); coche2.draw(); // Coche 2 (ID 3)
        glTranslatef(0.0, 0.0, 10.0);
        colorSeleccion(4); coche3.draw(); // Coche 3 (ID 4)
        glTranslatef(-15.0, 0.0, -10.0);
        colorSeleccion(5); dibujaTaburete(); // Taburete (ID 5)
        glTranslatef(-5.0, 0.0, -5.0);
        colorSeleccion(6); beethoven.draw(); // Beethoven (ID 6)
        glTranslatef(0.0, 0.0, 10.0);
        colorSeleccion(7); big_dodge.draw(); // Big Dodge (ID 7)
    } else {
        // Modo normal: asignar materiales y resaltar el objeto seleccionado
        GLfloat colorResaltado[] = {1.0f, 1.0f, 0.0f, 1.0f}; // Amarillo (resaltado)
        GLfloat colorNormal[] = {0.8f, 0.8f, 0.8f, 1.0f};    // Gris estándar

        if (objetoSeleccionado == 1) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        dado.draw();

        glTranslatef(10.0, 0.0, -10.0);
        if (objetoSeleccionado == 2) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        coche1.draw();

        glTranslatef(0.0, 0.0, 10.0);
        if (objetoSeleccionado == 3) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        coche2.draw();

        glTranslatef(0.0, 0.0, 10.0);
        if (objetoSeleccionado == 4) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        coche3.draw();

        glTranslatef(-15.0, 0.0, -10.0);
        if (objetoSeleccionado == 5) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        dibujaTaburete();

        glTranslatef(-5.0, 0.0, -5.0);
        if (objetoSeleccionado == 6) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        beethoven.draw();

        glTranslatef(0.0, 0.0, 10.0);
        if (objetoSeleccionado == 7) {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorResaltado);
        } else {
            glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colorNormal);
        }
        big_dodge.draw();
    }

    glPopMatrix();
}


/*
void dibujaEscena(bool seleccion){

  float morado[4]={0.8,0,1,1};
  float verde[4]={0,1,0,1};
  float rojo[4]={1,0,0,1};
  float azul[4]={0,0,1,1};
  float negro[4]={0,0,0,1};
  float blanco[4]={1,1,1,1};

  glPushMatrix ();		// Apila la transformacion geometrica actual
  
  glClearColor (0.0, 0.0, 0.0, 1.0);	// Fija el color de fondo a negro
  
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Inicializa el buffer de color y el Z-Buffer
  
  transformacionVisualizacion ();	// Carga transformacion de visualizacion


  // Dibujamos los ejes de coordenadas de forma que no se vean afectados por la iluminación
  
  glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT);
  glDisable(GL_LIGHTING);
  ejesCoordenadas.draw();			// Dibuja los ejes
  glPopAttrib();

  if(seleccion){
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    // Modo selección: asignar colores únicos
    glDisable(GL_LIGHTING); // Asegurar que la iluminación esté desactivada
    glDisable(GL_TEXTURE_2D); // Desactivar texturas si están activadas

    colorSeleccion(1); dado.draw(); // Dado con ID = 1
    glTranslatef(10.0, 0.0, -10.0);
    colorSeleccion(2); coche1.draw(); // Coche 1 con ID = 2
    glTranslatef(0.0, 0.0, 10.0);
    colorSeleccion(3); coche2.draw(); // Coche 2 con ID = 3
    glTranslatef(0.0, 0.0, 10.0);
    colorSeleccion(4); coche3.draw(); // Coche 3 con ID = 4
    glTranslatef(-15.0, 0.0, -10.0);
    colorSeleccion(5); dibujaTaburete(); // Taburete completo con ID = 5
    glTranslatef(-5.0, 0.0, -5.0);
    colorSeleccion(6); beethoven.draw(); // Beethoven con ID = 6
    glTranslatef(0.0, 0.0, 10.0);
    colorSeleccion(7); big_dodge.draw(); // Big Dodge con ID = 7
  
  }else{

    // Usamos la variable iluminacionActivada para que el color de los ejes no se vea 
    // afectado al alterar la iluminación
    if(iluminacionActivada){
      glEnable(GL_LIGHTING);
    }else{
      glDisable(GL_LIGHTING);
    }

      // Práctica 4

  dado.draw();

  glTranslatef(10.0,0.0,-10.0);
  coche1.draw();
  
  glTranslatef(0.0,0.0,10.0);
  coche2.draw();

  glTranslatef(0.0,0.0,10.0);
  coche3.draw();

  // Práctica 3
  
  glTranslatef(-15.0,0.0,-10.0);
  dibujaTaburete();

  // Práctica 2

  glTranslatef(-5.0,0.0,0.-5.0);
  glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE,verde);
  beethoven.draw();

  glTranslatef(0.0,0.0,10.0);
  glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE,rojo);
  big_dodge.draw();

  }
  
  glPopMatrix ();		// Desapila la transformacion geometrica
}
*/


/**
 * @brief Procedimiento de dibujo del modelo. Es llamado por glut cada vez que se debe redibujar.
*/
void Dibuja (void){
  dibujaEscena(false);
  glutSwapBuffers ();		// Intercambia el buffer de dibujo y visualizacion
}


/**
 * @brief Procedimiento de fondo. Es llamado por glut cuando no hay eventos pendientes.
*/
void idle (int v){

  // Actualización de la velocidad de escalado de altura del cilindro
  if(animacionActiva){
    if(alturaCilindro>=2.0f || alturaCilindro<=0.5f){
      VEL_Cilindro = -VEL_Cilindro;
    }

    alturaCilindro += VEL_Cilindro;

    // Actualización de la velocidad de rotación del asiento

    rotacionAsiento += VEL_Asiento;

    if(rotacionAsiento >= 360.0f || rotacionAsiento <= -360.0f){
      rotacionAsiento=0.0f;  
    }

    // Actualización de la velocidad de rotación (inclinación) del respaldo
    
    if(inclinacionRespaldo >= 0.0f || inclinacionRespaldo <= -25.0f){
      VEL_Respaldo = -VEL_Respaldo;
    }

    inclinacionRespaldo += VEL_Respaldo; 
  }
  

  glutPostRedisplay ();		// Redibuja
  glutTimerFunc (30, idle, 0);	// Vuelve a activarse dentro de 30 ms
}